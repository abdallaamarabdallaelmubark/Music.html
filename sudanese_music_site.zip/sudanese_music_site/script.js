const tracks = [
  {id:1,title:"الطير المهاجر",artist:"محمد وردي",genre:"كلاسيك",cover:"c1",symbol:"✦"},
  {id:2,title:"إزيكم كيفنكم",artist:"سيد خليفة",genre:"كلاسيك",cover:"c2",symbol:"♪"},
  {id:3,title:"يا حليوة",artist:"أغنية من التراث",genre:"شعبي",cover:"c3",symbol:"♫"},
  {id:4,title:"أغاني الطمبور",artist:"من شمال السودان",genre:"طمبور",cover:"c4",symbol:"✳"},
  {id:5,title:"صوت جديد",artist:"أصوات سودانية معاصرة",genre:"حديث",cover:"c5",symbol:"♪"},
  {id:6,title:"إيقاع من السودان",artist:"موسيقى شعبية",genre:"شعبي",cover:"c6",symbol:"♬"}
];
let activeFilter = "الكل";
let favorites = new Set();
let currentTrack = null;
let playing = false;

const grid = document.getElementById("trackGrid");
const searchInput = document.getElementById("searchInput");
const emptyState = document.getElementById("emptyState");
const toast = document.getElementById("toast");

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 2200);
}
function renderTracks() {
  const q = searchInput.value.trim().toLowerCase();
  const visible = tracks.filter(t => (activeFilter === "الكل" || t.genre === activeFilter) &&
    `${t.title} ${t.artist} ${t.genre}`.toLowerCase().includes(q));
  grid.innerHTML = visible.map(t => `
    <article class="track-card">
      <div class="cover ${t.cover}">${t.symbol}</div>
      <div class="track-info"><h3>${t.title}</h3><p>${t.artist}</p><span class="tag">${t.genre}</span></div>
      <div class="card-actions">
        <button class="icon-btn ${favorites.has(t.id) ? "favorited" : ""}" data-fav="${t.id}" aria-label="إضافة ${t.title} للمفضلة">${favorites.has(t.id) ? "♥" : "♡"}</button>
        <button class="play-small" data-play="${t.id}" aria-label="تشغيل ${t.title}">▶</button>
      </div>
    </article>`).join("");
  emptyState.hidden = visible.length !== 0;
}
function renderFavorites() {
  document.getElementById("favoriteCount").textContent = favorites.size;
  const list = document.getElementById("favoriteList");
  if (!favorites.size) {
    list.innerHTML = '<span class="favorite-empty">قائمتك فارغة حالياً — ابدأ بإضافة المقاطع التي تحبها.</span>';
    return;
  }
  list.innerHTML = [...favorites].map(id => {
    const t = tracks.find(x => x.id === id);
    return `<span class="favorite-chip">${t.title} — ${t.artist}<button data-remove="${id}" aria-label="حذف ${t.title} من المفضلة">×</button></span>`;
  }).join("");
}
function selectTrack(id) {
  currentTrack = tracks.find(t => t.id === Number(id));
  if (!currentTrack) return;
  document.getElementById("playerTitle").textContent = currentTrack.title;
  document.getElementById("playerArtist").textContent = currentTrack.artist;
  document.getElementById("playerCover").textContent = currentTrack.symbol;
  playing = false;
  updatePlayButton();
  document.getElementById("playerStatus").textContent = "لا يوجد صوت مرفق";
  showToast("هذه نسخة تجريبية: أضف ملفاً صوتياً مرخّصاً لتفعيل التشغيل.");
}
function updatePlayButton() {
  document.getElementById("playBtn").textContent = playing ? "Ⅱ" : "▶";
}
document.getElementById("filters").addEventListener("click", e => {
  const btn = e.target.closest("[data-filter]");
  if (!btn) return;
  activeFilter = btn.dataset.filter;
  document.querySelectorAll(".filter").forEach(b => b.classList.toggle("active", b === btn));
  renderTracks();
});
searchInput.addEventListener("input", renderTracks);
document.addEventListener("click", e => {
  const fav = e.target.closest("[data-fav]");
  const play = e.target.closest("[data-play]");
  const remove = e.target.closest("[data-remove]");
  if (fav) {
    const id = Number(fav.dataset.fav);
    favorites.has(id) ? favorites.delete(id) : favorites.add(id);
    renderTracks(); renderFavorites();
    showToast(favorites.has(id) ? "أُضيف إلى المفضلة" : "أُزيل من المفضلة");
  }
  if (play) selectTrack(play.dataset.play);
  if (remove) {
    favorites.delete(Number(remove.dataset.remove));
    renderTracks(); renderFavorites();
  }
});
document.getElementById("playBtn").addEventListener("click", () => {
  if (!currentTrack) { showToast("اختر مقطعاً أولاً من القائمة."); return; }
  showToast("التشغيل الصوتي غير مفعّل في النسخة الأولية.");
});
function stepTrack(direction) {
  const index = currentTrack ? tracks.findIndex(t => t.id === currentTrack.id) : 0;
  selectTrack(tracks[(index + direction + tracks.length) % tracks.length].id);
}
document.getElementById("nextBtn").addEventListener("click", () => stepTrack(1));
document.getElementById("prevBtn").addEventListener("click", () => stepTrack(-1));
document.getElementById("menuBtn").addEventListener("click", () => document.querySelector(".topbar nav").classList.toggle("open"));
renderTracks();
renderFavorites();
